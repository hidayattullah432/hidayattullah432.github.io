

<?php $__env->startSection('title', 'post'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="col-md-12 col-sm-12">
			<div class="oo">

				<img style="margin-top: 40px;" src="<?php echo e(asset("/storage/" . $post->cover)); ?>" alt="kliping">
			</div>
			<h2><?php echo e($post->title); ?></h2>
			<p><?php echo e($post->body); ?></p>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\A.Data\WEB\Laravel\Kliping\resources\views/posts/show.blade.php ENDPATH**/ ?>