<!doctype <!DOCTYPE html>
<html lang="en" id="home">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- the above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <title><?php echo $__env->yieldContent('title'); ?></title>
	<!-- boostrap -->
	<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
	
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/hp.css')); ?>" rel="stylesheet">
    
	
    </head>
    
<body>

    <?php echo $__env->make('layouts.navigasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>



	<?php echo $__env->yieldContent('footer'); ?>



    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/navbar.js')); ?>"></script>

</body>
</html>
       

<?php /**PATH D:\A.Data\WEB\Laravel\Kliping\resources\views/layouts/master.blade.php ENDPATH**/ ?>